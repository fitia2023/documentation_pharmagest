package mu.pharmagest.pharmagestapp;

import mu.pharmagest.pharmagestapp.LienBD.ConnectionBD;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.SQLException;


public class ConnectionBDTest {
    @Test
    public void testconnetion(){
        try {
            Connection connection = ConnectionBD.getConnexion();
            if (connection != null) {
                System.out.println("Connection reussi");
            }
        }catch (Exception e){
            System.out.println("Probleme de connection");
            e.printStackTrace();

        }

    }

}
