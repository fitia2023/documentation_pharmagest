package mu.pharmagest.pharmagestapp;

import mu.pharmagest.pharmagestapp.LienBD.DAO.PrescriptionDAO;
import mu.pharmagest.pharmagestapp.Modele.Prescrition;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;

public class PrescriptionTest {

    @Test
    public void test() throws SQLException, ParseException {

        PrescriptionDAO prescriptionDAO = new PrescriptionDAO();

    }
    private void fait(PrescriptionDAO prescriptionDAO) throws SQLException, ParseException {

        prescriptionDAO.deletePrescription(3);
        prescriptionDAO.deletePrescription(4);
        prescriptionDAO.deletePrescription(9);
        prescriptionDAO.deletePrescription(10);

        System.out.println(
                prescriptionDAO.getPrescriptionById(1).getNom_medecin()
        );

        LocalDate localDate = LocalDate.now();
        java.util.Date utilDate = java.sql.Date.valueOf(localDate);

        if (prescriptionDAO.addPrescription(
                new Prescrition(
                        4,
                        "Dr. Eric",
                        utilDate,
                        "Dadafara"
                )
        )){
            System.out.println("Bien ajouter");
        }
        String dateString = "2024-02-08";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        if (
                prescriptionDAO.updatePrecription(
                        new Prescrition(
                                2,
                                "Dr. Johnson",
                                dateFormat.parse(dateString),
                                "Bob")
                )
        ){
            System.out.println("Mis a jours reussi");
        }

        for (Prescrition p: prescriptionDAO.getallprescription()) {
            System.out.println(p.getNom_medecin());
        }

    }
}
