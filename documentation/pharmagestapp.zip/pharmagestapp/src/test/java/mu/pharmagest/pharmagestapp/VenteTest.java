package mu.pharmagest.pharmagestapp;

import mu.pharmagest.pharmagestapp.LienBD.DAO.PrescriptionDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.VenteDAO;
import mu.pharmagest.pharmagestapp.LienBD.Services.VenteService;
import mu.pharmagest.pharmagestapp.Modele.LigneVente;
import mu.pharmagest.pharmagestapp.Modele.Medicament;
import mu.pharmagest.pharmagestapp.Modele.Prescrition;
import mu.pharmagest.pharmagestapp.Modele.Vente;
import org.junit.jupiter.api.Test;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class VenteTest {

    @Test
    public void test() throws SQLException {

    }

    private void fait(VenteDAO venteDAO, PrescriptionDAO prescriptionDAO) throws SQLException {


        LocalDate localDate = LocalDate.now();
        java.util.Date utilDate = java.sql.Date.valueOf(localDate);

        VenteService venteService = new VenteService();

        venteDAO.deleteVente(7);
        venteDAO.deleteVente(6);
        venteDAO.deleteVente(5);


        if (venteDAO.deleteVente(4)) {
            System.out.println("Vente bien supprime");
        }

        for (Vente vente : venteDAO.getallvente()) {
            System.out.println(vente.getPrescrition() != null ? vente.getPrescrition().getNom_medecin() : "vide");
        }



        if (venteDAO.addVentePrescription(
                new Vente(
                        1,
                        utilDate,
                        11.0,
                        false,
                        prescriptionDAO.getPrescriptionById(1)
                )
        )) {
            System.out.println("add avec prescription bien");
        }
        if (venteDAO.updateVente(
                new Vente(
                        5,
                        utilDate,
                        20.0,
                        false,
                        prescriptionDAO.getPrescriptionById(1)
                )
        )) {
            System.out.println("Vente 5 bien modifie");
        }
        for (Vente vente : venteDAO.getVentesByDate(Date.valueOf("2024-02-09"))) {
            System.out.println(vente.getId_vente());
        }
        System.out.println(venteDAO.getVenteById(5).getDate_vente());

    }

}
