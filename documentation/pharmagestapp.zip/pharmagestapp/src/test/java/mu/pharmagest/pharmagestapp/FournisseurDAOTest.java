package mu.pharmagest.pharmagestapp;

import mu.pharmagest.pharmagestapp.LienBD.DAO.FournisseurDAO;
import mu.pharmagest.pharmagestapp.Modele.Fournisseur;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;

public class FournisseurDAOTest {

    @Test
    public void tesdtvwdvs() throws SQLException {
        FournisseurDAO fournisseurDAO = new FournisseurDAO();

        for (Fournisseur f: fournisseurDAO.getallfournisseurs()) {
            System.out.println(f.getNom_fournisseur());
        }
    }


}
