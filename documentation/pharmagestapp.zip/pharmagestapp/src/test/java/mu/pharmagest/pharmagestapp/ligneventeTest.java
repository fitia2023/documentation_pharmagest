package mu.pharmagest.pharmagestapp;

import mu.pharmagest.pharmagestapp.LienBD.DAO.LigneVenteDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.MedicamentDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.VenteDAO;
import mu.pharmagest.pharmagestapp.Modele.LigneVente;
import mu.pharmagest.pharmagestapp.Modele.Medicament;
import mu.pharmagest.pharmagestapp.Modele.Vente;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.time.LocalDate;

public class ligneventeTest {

    @Test
    public void test() throws SQLException {
        MedicamentDAO medicamentDAO = new MedicamentDAO();
        VenteDAO venteDAO = new VenteDAO();
        LigneVenteDAO ligneVenteDAO = new LigneVenteDAO();


    }

    private void fait(LigneVenteDAO ligneVenteDAO, MedicamentDAO medicamentDAO, VenteDAO venteDAO) throws SQLException {
        for (LigneVente l : ligneVenteDAO.getalllignevente()) {
            System.out.println(l.getMedicament().getNom_medicament());
        }

        ligneVenteDAO.deleteVenteLigne(7);
        ligneVenteDAO.deleteVenteLigne(6);

        for (LigneVente l : ligneVenteDAO.getLigneVentesById(3)) {
            System.out.println(l.getMedicament().getNom_medicament());
        }

        LocalDate localDate = LocalDate.now();
        java.util.Date utilDate = java.sql.Date.valueOf(localDate);
        if (ligneVenteDAO.addLigneVente(
                new LigneVente(
                        new Vente(
                                3,
                                utilDate,
                                11.0,
                                false,
                                null
                        ),
                        new Medicament(
                                1,
                                null,
                                null,
                                null,
                                null,
                                null,
                                null,
                                null,
                                null,
                                null,
                                null
                        ),
                        8
                )
        )) {
            System.out.println("Bien ajouter");
        }

        if (ligneVenteDAO.deleteVenteLigne(3)){
            System.out.println("Bien enleve");
        }
    }

}
