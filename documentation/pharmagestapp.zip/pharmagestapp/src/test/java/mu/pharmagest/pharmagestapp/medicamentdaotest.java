package mu.pharmagest.pharmagestapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import mu.pharmagest.pharmagestapp.LienBD.DAO.MedicamentDAO;
import mu.pharmagest.pharmagestapp.Modele.Medicament;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;

public class medicamentdaotest {

    @Test
    public void getallmedicament() throws SQLException {

    }
    public void getall() throws SQLException {
        MedicamentDAO medicamentDAO = new MedicamentDAO();

        ObservableList<Medicament> medicaments = FXCollections.observableList(medicamentDAO.getallmedicament());
        System.out.println(medicaments.size());
    }

}
