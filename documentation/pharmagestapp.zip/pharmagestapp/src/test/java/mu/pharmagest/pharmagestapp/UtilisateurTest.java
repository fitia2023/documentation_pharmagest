package mu.pharmagest.pharmagestapp;

import mu.pharmagest.pharmagestapp.LienBD.DAO.UtilisateurDAO;
import mu.pharmagest.pharmagestapp.Modele.Utilisateur;
import org.junit.jupiter.api.Test;

public class UtilisateurTest {

    @Test
    public void testconnection(){

    }
    @Test
    public void utilisateur(){

    }

    public void get(){
        UtilisateurDAO utilisateurDAO = new UtilisateurDAO();
        Utilisateur utilisateur = utilisateurDAO.getUtilisateurConnecter("Pharmacien","admin");

        if (utilisateurDAO.sAuthentifier("Pharmacien","admin")){

            System.out.println("Connexion bien fait");

        }else {
            System.out.println("Connexion non autorise");
        }

        if (utilisateur != null){

            System.out.println("Nom:" + utilisateur.getNom_utilisateur());

        }else {
            System.out.println("Connexion non autorise");
        }
    }
}
