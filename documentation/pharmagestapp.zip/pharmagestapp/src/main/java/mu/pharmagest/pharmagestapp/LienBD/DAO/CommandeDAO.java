package mu.pharmagest.pharmagestapp.LienBD.DAO;

import mu.pharmagest.pharmagestapp.LienBD.ConnectionBD;
import mu.pharmagest.pharmagestapp.Modele.Commande;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//Responsable de la commande vers la base de donnee
public class CommandeDAO {

    private Connection connection;

    private FournisseurDAO fournisseurDAO;

    public CommandeDAO() {
        this.connection = ConnectionBD.getConnexion();
        this.fournisseurDAO = new FournisseurDAO();
    }


    //Obtenir commande par id
    public Commande getcommandebyid(Integer id) throws SQLException {
        // Requête SQL pour récupérer les fournisseurs par nom (utilisation de LIKE pour une recherche partielle)
        String requete = "SELECT * FROM commande WHERE id_commande = ?;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            // Définir le paramètre dans la requête préparée avec id commande
            preparedStatement.setInt(1,id);

            // Exécuter la requête SQL
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if(resultSet.next()){
                    return mapCommande(resultSet);
                }else {
                    return null;
                }
            }
        } catch (SQLException e) {
            // Gérer l'exception en cas d'erreur SQL
            throw new SQLException("Erreur lors de la récupération commande par id. Cause : " + e.getMessage(), e);
        }
    }

    // Obtenir le dernier ID de commande
    public int getLastIdCommande() throws SQLException {
        String requete = "SELECT MAX(id_commande) AS last_id FROM commande;";
        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt("last_id");
                } else {
                    throw new SQLException("La table commande est vide.");
                }
            }
        } catch (SQLException e) {
            throw new SQLException("Erreur lors de la récupération du dernier ID de commande. Cause : " + e.getMessage(), e);
        }
    }

    //Ajout du commande
    public Boolean addCommande(Commande commande) throws SQLException {
        String requete = "INSERT INTO commande (id_commande, prix_total, id_fournisseur) VALUES (?, ?, ? );";

        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            preparedStatement.setInt(1, commande.getId_commande());
            preparedStatement.setDouble(2, commande.getPrix_total());
            preparedStatement.setInt(3, commande.getFournisseur().getId_fournisseur());
            int rowCount = preparedStatement.executeUpdate();

            return rowCount > 0;
        } catch (SQLException e) {
            // Gérer l'exception selon vos besoins
            throw new SQLException("Erreur lors de l'ajout du commande", e);
        }

    }

    //Pour changer statut en termine
    public Boolean commandetermine(Integer id, Double prix) throws SQLException {
        String requete = "UPDATE commande SET prix_payer = ? , statut = ? WHERE id_commande = ?;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            preparedStatement.setString(2,"Terminée");
            preparedStatement.setDouble(1, prix );
            preparedStatement.setInt(3, id);
            int rowCount = preparedStatement.executeUpdate();

            return rowCount > 0;
        } catch (SQLException e) {
            // Gérer l'exception selon vos besoins
            throw new SQLException("Erreur lors de la mis a jours du commande", e);
        }
    }

    //Map de commande
    private Commande mapCommande(ResultSet resultSet) throws SQLException {
        return new Commande(
                resultSet.getInt("id_commande"),
                resultSet.getDate("date_commande"),
                resultSet.getDouble("prix_total"),
                fournisseurDAO.getFournisseursById(resultSet.getInt("id_fournisseur")),
                resultSet.getDouble("prix_payer"),
                resultSet.getString("statut")
        );
    }
}
