package mu.pharmagest.pharmagestapp.LienBD.Services;


import mu.pharmagest.pharmagestapp.LienBD.DAO.*;
import mu.pharmagest.pharmagestapp.Modele.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CommandeService {

    private MedicamentDAO medicamentDAO;

    private FournisseurDAO fournisseurDAO;

    private CommandeDAO commandeDAO;

    private LigneCommandeDAO ligneCommandeDAO;

    private ListePrixDAO listePrixDAO;


    public CommandeService() {
        this.commandeDAO = new CommandeDAO();
        this.fournisseurDAO = new FournisseurDAO();
        this.medicamentDAO = new MedicamentDAO();
        this.listePrixDAO = new ListePrixDAO();
        this.ligneCommandeDAO = new LigneCommandeDAO();
    }

    //Ajout de la commande avec ligne
    public Boolean addLCommande(LigneCommande ligneCommande) throws SQLException {
        Boolean reponse = false;
        Commande commande = ligneCommande.getCommande();
        if (commandeDAO.addCommande(ligneCommande.getCommande())) {
            if (ligneCommandeDAO.addLigneCommande(ligneCommande)) {
                reponse = true;
            }
        }
        return reponse;
    }

    //Avoir la liste des medicaments en dessous du seuil
    public List<Medicament> suggestioncommande() throws SQLException {
        List<Medicament> medicaments = new ArrayList<>();
        for (Medicament medicament : medicamentDAO.getallmedicament()) {
            if (medicament.getQt_stock() < medicament.getSeuil_commande()) {
                medicaments.add(medicament);
            }
        }
        return medicaments;
    }

    //Obtenir le dernier commande
    public Integer getLastIdCommande() throws SQLException {
        return commandeDAO.getLastIdCommande();
    }

    //Tous les midicaments
    public List<Medicament> getallmedicament() throws SQLException {
        return medicamentDAO.getallmedicament();
    }

    //Tous les fournisseurs
    public List<Fournisseur> getallfournisseur() throws SQLException {
        return fournisseurDAO.getallfournisseurs();
    }

    //Liste fournisseur par un medicament
    public List<ListePrix> getallFournisseurbyid_medicament(Integer id_medicament) throws SQLException {
        return listePrixDAO.listefournisseurparidmedicament(id_medicament);
    }

    //Liste medicament par nom
    public List<Medicament> getallmedicmanetbyname(String nom_medicament) throws SQLException {
        return medicamentDAO.getMedicamentsByName(nom_medicament);
    }

    //ListePrix par id medic et fournisseur
    public ListePrix getListPrixbyid(Integer id_medicament, Integer id_fournisseur) throws SQLException {
        return listePrixDAO.getListPrixbyid(id_medicament, id_fournisseur);
    }

    //Obtenir fournisseur par id fournisseur
    public Fournisseur getfournisseurbyid(Integer id_fournisseur) throws SQLException {
        return fournisseurDAO.getFournisseursById(id_fournisseur);
    }

    //Obtenir fournisseur par nom
    public List<Fournisseur> getallfournisseurbyname(String nom_fournisseur) throws SQLException {
        return fournisseurDAO.getFournisseursByName(nom_fournisseur);
    }
}
