package mu.pharmagest.pharmagestapp.LienBD.DAO;

import mu.pharmagest.pharmagestapp.LienBD.ConnectionBD;
import mu.pharmagest.pharmagestapp.Modele.LigneCommande;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//Pour la commande de medicament detaillant selon la quantite
public class LigneCommandeDAO {

    private Connection connection;

    private MedicamentDAO medicamentDAO;

    private CommandeDAO commandeDAO;

    public LigneCommandeDAO(){
        this.connection = ConnectionBD.getConnexion();
        this.commandeDAO = new CommandeDAO();
        this.medicamentDAO = new MedicamentDAO();
    }

    //Pour ajout de panier commande
    public Boolean addLigneCommande(LigneCommande ligneCommande) throws SQLException {
        String requete = "INSERT INTO lignecommande (id_medicament, id_commande, qt_vente) VALUES (?, ?, ? );";

        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            preparedStatement.setInt(1, ligneCommande.getMedicament().getId_medicament());
            preparedStatement.setInt(2, ligneCommande.getCommande().getId_commande());
            preparedStatement.setDouble(3,ligneCommande.getQt_medicament());
            int rowCount = preparedStatement.executeUpdate();

            return rowCount > 0;
        } catch (SQLException e) {
            // Gérer l'exception selon vos besoins
            throw new SQLException("Erreur lors de l'ajout du lignecommande", e);
        }
    }

    //Obtenir toute la ligne de commande
    public List<LigneCommande> getallLigneCommande() throws SQLException {
        String requete = "SELECT * FROM lignecommande";

        List<LigneCommande> ligneCommandes = new ArrayList<>();

        PreparedStatement preparedStatement = connection.prepareStatement(requete);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            ligneCommandes.add(mapligneCommande(resultSet));
        }

        return ligneCommandes;
    }


    //up quantite recu de la commande
    public Boolean qtrecucommande(LigneCommande ligneCommande) throws SQLException {
        // Requête SQL pour mettre à jour un qt_recu
        String requete = "UPDATE lignecommande SET qt_recu = ? WHERE id_medicament = ? AND id_commande = ?;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            // Définir les valeurs des paramètres dans la requête préparée
            preparedStatement.setInt(1, ligneCommande.getQt_recu());
            preparedStatement.setInt(2, ligneCommande.getMedicament().getId_medicament());
            preparedStatement.setInt(3, ligneCommande.getCommande().getId_commande());

            // Exécuter la requête de mise à jour
            int rowCount = preparedStatement.executeUpdate();

            // Vérifier si au moins une ligne a été mise à jour
            return rowCount > 0;
        } catch (SQLException e) {
            // Gérer l'exception en cas d'erreur SQL
            throw new SQLException("Erreur lors de la mise à jour du lignecommande. Cause : " + e.getMessage(), e);
        }
    }

    //Obtenir map de ligne commange
    private LigneCommande mapligneCommande(ResultSet resultSet) throws SQLException {

        return new LigneCommande(
                medicamentDAO.getMedicamentById(resultSet.getInt("id_medicament")),
                commandeDAO.getcommandebyid(resultSet.getInt("id_commande")),
                resultSet.getInt("qt_vente"),
                resultSet.getInt("qt_recu")
        );

    }

}
