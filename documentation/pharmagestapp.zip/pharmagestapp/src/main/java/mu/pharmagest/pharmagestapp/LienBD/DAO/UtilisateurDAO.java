package mu.pharmagest.pharmagestapp.LienBD.DAO;

import mu.pharmagest.pharmagestapp.LienBD.ConnectionBD;
import mu.pharmagest.pharmagestapp.Modele.Utilisateur;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Classe responsable de l'interaction avec la table Utilisateur pour l'authentification.
 */
public class UtilisateurDAO {

    private final Connection connection;

    public UtilisateurDAO() {
        this.connection = ConnectionBD.getConnexion();
    }

    /**
     * Authentifie l'utilisateur en vérifiant les identifiants fournis.
     *
     * @param identifiant Identifiant de l'utilisateur.
     * @param motDePasse  Mot de passe de l'utilisateur.
     * @return true si l'authentification réussit, sinon false.
     */
    public boolean sAuthentifier(String identifiant, String motDePasse) {
        String requete = "SELECT COUNT(*) FROM Utilisateur WHERE identifiant = ? AND mot_de_passe = ? AND bloquer = false;";
        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            preparedStatement.setString(1, identifiant);
            preparedStatement.setString(2, motDePasse);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count == 1;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'authentification", e);
        }
        return false;
    }


    /**
     *Pour obtenir l'utilisateur connecter
     */
    public Utilisateur getUtilisateurConnecter(String identifiant, String motDePasse) {

        String requete = "SELECT * FROM Utilisateur WHERE identifiant = ? AND mot_de_passe = ? AND bloquer = false;";
        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            preparedStatement.setString(1, identifiant);
            preparedStatement.setString(2, motDePasse);

            // Exécuter la requête SQL
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return mapUtilisateur(resultSet);
                } else {
                    return null;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de recuperation", e);
        }
    }

    /*
     *Pour recuper l'utilisateur
     */
    private Utilisateur mapUtilisateur(ResultSet resultSet) throws SQLException {
        return new Utilisateur(
                resultSet.getInt("id_utilisateur"),
                resultSet.getString("nom_utilisateur"),
                resultSet.getString("prenom_utilisateur"),
                resultSet.getDate("annif_utilisateur"),
                resultSet.getString("adresse_utilisateur"),
                resultSet.getInt("tel_utilisateur"),
                resultSet.getString("identifiant"),
                "",
                Utilisateur.Role.valueOf(resultSet.getString("role")),
                resultSet.getBoolean("actif"),
                resultSet.getBoolean("bloquer")
        );

    }
}
