package mu.pharmagest.pharmagestapp.LienBD.Services;


import mu.pharmagest.pharmagestapp.LienBD.DAO.CommandeDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.LigneCommandeDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.ListePrixDAO;
import mu.pharmagest.pharmagestapp.Modele.Commande;
import mu.pharmagest.pharmagestapp.Modele.LigneCommande;
import mu.pharmagest.pharmagestapp.Modele.ListePrix;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//Pour pouvoir mettre a jour la base de donnee de commande recu
public class ReceptionCommandeService {

    private CommandeDAO commandeDAO;

    private LigneCommandeDAO ligneCommandeDAO;

    private ListePrixDAO listePrixDAO;

    public ReceptionCommandeService() {
        this.commandeDAO = new CommandeDAO();
        this.ligneCommandeDAO = new LigneCommandeDAO();
        this.listePrixDAO = new ListePrixDAO();
    }

    //Obtenir toutes les lignescommande
    public List<LigneCommande> getallcommande() throws SQLException {
        List<LigneCommande> ligneCommandes = new ArrayList<>();

        for (LigneCommande ligneCommande : ligneCommandeDAO.getallLigneCommande()) {
            if (ligneCommande.getCommande().getStatut().equals("En cours")) {
                ligneCommandes.add(ligneCommande);
            }
        }
        return ligneCommandes;
    }

    //Obtenir la liste selon id de la commande
    public List<LigneCommande> getallcommandebyid(Integer id) throws SQLException {

        Commande commande = commandeDAO.getcommandebyid(id);
        List<LigneCommande> ligneCommandes = new ArrayList<>();

        for (LigneCommande ligneCommande:ligneCommandeDAO.getallLigneCommande()){
            if (ligneCommande.getCommande().getId_commande().equals(commande.getId_commande())){
                ligneCommandes.add(ligneCommande);
            }
        }

        return ligneCommandes;

    }

    //ListePrix par id medic et fournisseur
    public ListePrix getListPrixbyid(LigneCommande ligneCommande) throws SQLException {
        return listePrixDAO.getListPrixbyid(ligneCommande.getMedicament().getId_medicament(), ligneCommande.getCommande().getFournisseur().getId_fournisseur());
    }


    //Pour mettre en termine la commande avec qt recu
    public Boolean terminercommande(LigneCommande ligneCommande) throws SQLException {
        Boolean reponse = false;
        if (ligneCommandeDAO.qtrecucommande(ligneCommande)){
            if (commandeDAO.commandetermine(ligneCommande.getCommande().getId_commande(),ligneCommande.getCommande().getPrix_payer())){
                reponse = true;
            }
        }
        return reponse;
    }
}
