package mu.pharmagest.pharmagestapp.LienBD.DAO;

import mu.pharmagest.pharmagestapp.LienBD.ConnectionBD;
import mu.pharmagest.pharmagestapp.Modele.LigneVente;
import mu.pharmagest.pharmagestapp.Modele.Medicament;
import mu.pharmagest.pharmagestapp.Modele.Vente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Pour obtenir les donnees de la base
 */
public class LigneVenteDAO {

    private final Connection connection;
    private final VenteDAO venteDAO;
    private final MedicamentDAO medicamentDAO;
    public LigneVenteDAO() {
        this.connection = ConnectionBD.getConnexion();
        this.venteDAO = new VenteDAO();
        this.medicamentDAO = new MedicamentDAO();
    }

    //Obtenir tous les lignesventes
    public List<LigneVente> getalllignevente() throws SQLException {

        String requete = "SELECT * FROM lignevente";

        List<LigneVente> ligneVentes = new ArrayList<>();

        PreparedStatement preparedStatement = connection.prepareStatement(requete);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            ligneVentes.add(maplignevente(resultSet));
        }

        return ligneVentes;
    }

    /**
     * Ajoute une lignevente à la base de données.
     * @throws SQLException En cas d'erreur lors de l'exécution de la requête SQL.
     */
    public boolean addLigneVente(LigneVente ligneVente) throws SQLException {
        String requete = "INSERT INTO lignevente(id_vente, id_medicament, qt) VALUES (?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            preparedStatement.setInt(1, ligneVente.getVente().getId_vente());
            preparedStatement.setInt(2, ligneVente.getMedicament().getId_medicament());
            preparedStatement.setInt(3, ligneVente.getQt());

            int rowCount = preparedStatement.executeUpdate();

            return rowCount > 0;
        } catch (SQLException e) {
            // Gérer l'exception selon vos besoins
            throw new SQLException("Erreur lors de l'ajout du lignevente", e);
        }
    }

    /**
     * Supprime vente de la base de données.
     *
     * @param idVente Identifiant du vente à supprimer.
     * @return True si la suppression réussit, sinon False.
     * @throws SQLException En cas d'erreur lors de l'exécution de la requête SQL.
     */
    public boolean deleteVenteLigne(Integer idVente) throws SQLException {
        String requete = "DELETE FROM lignevente WHERE id_vente = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(requete)) {
            preparedStatement.setInt(1, idVente);

            int rowCount = preparedStatement.executeUpdate();

            return rowCount > 0;
        } catch (SQLException e) {
            // Vous pouvez ajouter des informations supplémentaires si nécessaire
            throw new SQLException("Erreur lors de la suppression du vente ligne. Cause : " + e.getMessage(), e);
        }
    }

    /**
     * Récupère vente par id.
     *
     * @param id dont id_vente
     * @return lignevente correspondant à l'id.
     * @throws SQLException En cas d'erreur lors de l'exécution de la requête SQL.
     */
    public List<LigneVente> getLigneVentesById(Integer id) throws SQLException {
        // Requête SQL pour récupérer les lignevente par id
        String requete = "SELECT * FROM lignevente WHERE id_vente = ?;";

        List<LigneVente> ligneVentes = new ArrayList<>();

        PreparedStatement preparedStatement = connection.prepareStatement(requete);
        // Définir la valeur du paramètre id_vente
        preparedStatement.setInt(1, id);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            ligneVentes.add(maplignevente(resultSet));
        }

        return ligneVentes;
    }

    //Obtenir ligneVente
    private LigneVente maplignevente(ResultSet resultSet) throws SQLException {

        Vente vente = venteDAO.getVenteById(
                resultSet.getInt("id_vente")
        );
        Medicament medicament = medicamentDAO.getMedicamentById(
                resultSet.getInt("id_medicament")
        );

        return new LigneVente(
                vente,
                medicament,
                resultSet.getInt("qt")
        );

    }

}
