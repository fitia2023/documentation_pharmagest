package mu.pharmagest.pharmagestapp.LienBD.Services;

import mu.pharmagest.pharmagestapp.LienBD.ConnectionBD;
import mu.pharmagest.pharmagestapp.LienBD.DAO.LigneVenteDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.PrescriptionDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.VenteDAO;
import mu.pharmagest.pharmagestapp.Modele.LigneVente;
import mu.pharmagest.pharmagestapp.Modele.Prescrition;
import mu.pharmagest.pharmagestapp.Modele.Vente;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class VenteService {

    private PrescriptionDAO prescriptionDAO;
    private VenteDAO venteDAO;
    private LigneVenteDAO ligneVenteDAO;


    public VenteService() {
        this.prescriptionDAO = new PrescriptionDAO();
        this.venteDAO = new VenteDAO();
        this.ligneVenteDAO = new LigneVenteDAO();
    }

    public Integer getNumPrescriSuivant() throws SQLException {

        Integer nbr = prescriptionDAO.getallprescription().get(
                prescriptionDAO.getallprescription().size() - 1
        ).getId_prescription();
        nbr += 1;
        return nbr;
    }

    public Integer getNumVenteSuivant() throws SQLException {

        Integer nbr = venteDAO.getallvente().get(
                venteDAO.getallvente().size() - 1
        ).getId_vente();
        nbr += 1;
        return nbr;
    }

    public boolean addventePrescription(Prescrition prescrition, Vente vente, List<LigneVente> ligneVentes) throws SQLException {
        boolean add = false;

        // Ajoutez la prescription
        if (prescriptionDAO.addPrescription(prescrition)) {
            // Ajoutez la vente
            if (venteDAO.addVentePrescription(vente)) {
                for (LigneVente ligneVente : ligneVentes) {
                    if (ligneVenteDAO.addLigneVente(ligneVente)) {
                        add = true;
                    }
                }
            }
        }

        return add;
    }

    public boolean addvente(Vente vente, List<LigneVente> ligneVentes) throws SQLException {

        boolean add = false;

        // Ajoutez la vente
        if (venteDAO.addVente(vente)) {
            for (LigneVente ligneVente : ligneVentes) {
                if (ligneVenteDAO.addLigneVente(ligneVente)) {
                    add = true;
                }
            }
        }

        return add;
    }
}
