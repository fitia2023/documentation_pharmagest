package mu.pharmagest.pharmagestapp.LienBD.Services;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import mu.pharmagest.pharmagestapp.Controller.Vente.ModelVente;
import mu.pharmagest.pharmagestapp.LienBD.DAO.LigneVenteDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.MedicamentDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.PrescriptionDAO;
import mu.pharmagest.pharmagestapp.LienBD.DAO.VenteDAO;
import mu.pharmagest.pharmagestapp.Modele.LigneVente;
import mu.pharmagest.pharmagestapp.Modele.Medicament;
import mu.pharmagest.pharmagestapp.Modele.Vente;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CaisseService {
    private PrescriptionDAO prescriptionDAO;
    private VenteDAO venteDAO;
    private LigneVenteDAO ligneVenteDAO;

    private MedicamentDAO medicamentDAO;

    public CaisseService() {
        this.prescriptionDAO = new PrescriptionDAO();
        this.venteDAO = new VenteDAO();
        this.ligneVenteDAO = new LigneVenteDAO();
        this.medicamentDAO = new MedicamentDAO();
    }

    public List<Vente> getallventenonpayer() throws SQLException {
        List<Vente> ventes = new ArrayList<>();
        for (Vente vente: venteDAO.getallvente()) {
            if (!vente.getPayer()){
                ventes.add(vente);
            }
        }
        return ventes;
    }

    public List<ModelVente> getallmodelvente(Vente vente) throws SQLException {
        List<ModelVente> modelVentes = new ArrayList<>();
        int id_vente = vente.getId_vente();
        for (LigneVente lignevente: ligneVenteDAO.getLigneVentesById(id_vente) ) {
            modelVentes.add(
                    new ModelVente(
                            lignevente.getMedicament(),
                            lignevente.getMedicament().getPrix_vente(),
                            lignevente.getQt(),
                            vente.getPrix_total()
                    )
            );
        }
        return modelVentes;
    }

    public ObservableList<Vente> getallventenonpayerId(int id_vente) throws SQLException {
        Vente vente = venteDAO.getVenteById(id_vente);
        ObservableList<Vente> ventes = FXCollections.observableArrayList();
        if (vente != null && !vente.getPayer()) {
            ventes.add(vente);
        }
        return ventes;
    }

    public boolean payervente(Vente vente) throws SQLException {
        if (venteDAO.upventepayer(vente)) {
            for (ModelVente modelVente : getallmodelvente(vente)) {
                Medicament medicament = modelVente.getMedicament();
                int qt_stock = medicament.getQt_stock();
                qt_stock -= modelVente.getQt();
                medicament.setQt_stock(qt_stock);
                if (!medicamentDAO.updateMedicament(medicament)) {
                    return false; // Si la mise à jour du stock échoue, retourner false
                }
            }
            return true; // Si toutes les mises à jour du stock réussissent, retourner true
        }
        return false; // Si la mise à jour de la vente échoue, retourner false
    }

}
